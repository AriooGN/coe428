Question 1:

towers(4,2,1)
towers will be called 5 times
from towers 2 to 3
towers(3,2,3)


Question 2:
255 lines -> according to the formula (2^n)-1 with n being number of rings


I have completed all requirements.
-Arian Fooladray